# maven_training
![example workflow](https://github.com/Lairopw/maven_training/actions/workflows/build.yml/badge.svg)
[![codecov](https://codecov.io/gh/Lairopw/maven_training/branch/main/graph/badge.svg)](https://codecov.io/gh/Lairopw/maven_training)

